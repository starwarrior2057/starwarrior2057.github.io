A Pen created at CodePen.io. You can find this one at http://codepen.io/DESTROYER2057/pen/qNLRVV.

 